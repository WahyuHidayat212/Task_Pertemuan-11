// make mahasiswa data
const mahasiswa = [
    {
        nama : "Wahyu Hidayat",
        gender  : "laki - laki",
        umur : 19,
    },
    {
        nama : "Winda Amelia",
        gender  : "peremupan",
        umur : 20,
    },
    {
        nama : "Megawati",
        gender  : "perempuan",
        umur : 50,
    },
    {
        nama : "Kaesang Pangarep",
        gender  : "laki - laki",
        umur : 25,
    }
];

module.exports = mahasiswa;